Настройки доступа к mysql находятся в файле pdoconfig.php в папке src
Пользователи админки admin@mail.ru и operator@mail.ru, пароль к обоим 123456
