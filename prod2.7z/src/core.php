<?php
include_once __DIR__ . '/config.php';
include_once __DIR__ . '/functions.php';
include_once __DIR__ . '/main_menu.php';
include_once __DIR__ . '/login.php';
include_once __DIR__ . '/pdoconfig.php';
include_once __DIR__ . '/pdoconnect.php';
include_once __DIR__ . '/sub_menu.php';
