<?php
$mainMenu = [
    [
        'title' => 'Главная',
        'path' => '/',
        'sort' => 10,
    ],
    [
        'title' => 'Новинки',
        'path' => '/?new',
        'sort' => 12,
    ],
    [
        'title' => 'Sale',
        'path' => '/?sale',
        'sort' => 14,
    ],
    [
        'title' => 'Доставка',
        'path' => '/delivery/',
        'sort' => 16,
    ],
];
