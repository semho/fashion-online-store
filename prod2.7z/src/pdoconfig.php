<?php
$host = 'localhost';
$dbname = 'fashion';
$username = 'root';
$password = 'root';
